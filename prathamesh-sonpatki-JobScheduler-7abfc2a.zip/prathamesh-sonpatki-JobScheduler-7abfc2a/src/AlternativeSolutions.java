/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author prathamesh
 */
public class AlternativeSolutions {
        int MachineID;
        int time;

    public AlternativeSolutions(int machine,int t) {
        MachineID = machine;
        time      = t;
    }



}
