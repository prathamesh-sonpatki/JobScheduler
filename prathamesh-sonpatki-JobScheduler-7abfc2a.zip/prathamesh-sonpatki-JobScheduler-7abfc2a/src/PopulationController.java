

import java.io.FileNotFoundException;


/*
 * Generates and controlles population.
 */

/**
 *
 * @author chaitanya
 */
public class PopulationController {
 Population population;


    public PopulationController() {
    population = null;
    }


 public void GetPopulationDetails(Job [] job)
    {

        population = new Population();
        population.setPopulationSize(jobScheduler.populationSize);

        population.setChromosomes(job);
       




    }


}
