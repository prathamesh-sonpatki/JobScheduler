
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chaitanya
 */
public class Population extends Job{
    int populationSize;
    Chromosome chromosomes[];

    public Population() {
    populationSize = 0;
  //  chromosomes = null;
    }

    public void setChromosomes(Job job[]) {

      
        chromosomes = new Chromosome[jobScheduler.populationSize];
        chromosomes[0] = new Chromosome();
             
      int length = 0;
        for(int i=0;i<job.length;i++)
            length+= job[i].getTotalOperations();
       chromosomes[0].setGeneCount(job.length);
       chromosomes[0].setChromosomeLength(length);

       chromosomes[0].setGenes(job);
       chromosomes[0].printChromosome();
        


  

        
    }

    public void setPopulationSize(int populationSize) {
        this.populationSize = populationSize;
    }

    public Chromosome getChromosomes() {
        return chromosomes[0];
    }

    public int getPopulationSize() {
        return populationSize;
    }


}
