/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chaitanya
 */
public class GeneSolution {
    int MachineID;
    int time;

    public GeneSolution(int MachineID, int time) {
        
        this.MachineID = MachineID;
        this.time = time;
    }

   

    public void printGeneSolution()
    {
        System.out.print("["+MachineID +"] ("+time+") ");
    }
    public void setMachineID(int MachineID) {
        this.MachineID = MachineID;
    }

    public void setTime(int time) {
        this.time = time;
    }



    public int getMachineID() {
        return MachineID;
    }

    public int getTime() {
        return time;
    }


}
