/*
 * Machine Class ; Gives Information about Available Machines
 */

/**
 *
 * @author prathamesh
 */
public class Machine {
    private int MachineID;

    Machine(int ID)
        {
            MachineID = ID;
        }

}
