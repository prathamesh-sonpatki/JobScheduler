
import java.util.List;
import java.util.Random;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chaitanya
 */
public class Gene {
    static int k=0;
    int geneLength;
    GeneSolution [] geneSolution;

    public Gene() {
        this.geneLength = 0;
        this.geneSolution = null;

    }

    public GeneSolution[] getGeneSolution() {
        return geneSolution;
    }

    public int getGeneLength() {
        return geneLength;
    }

    public void setGeneLength(int geneLength) {
        this.geneLength = geneLength;
    }
    public void printGenes()
    {
        System.out.println("Gene Length "+this.getGeneLength());
        for(int i=0;i<this.getGeneLength();i++)
        {
            
           geneSolution[i].printGeneSolution();

        }
        System.out.println();
    }
    public void setGeneSolution(Job job[],int i) {

        // Create random class object
       geneSolution = new GeneSolution[geneLength];
       Random r = new Random();
       
      
        
           for(int j=0;j<job[i].getTotalOperations();j++)
           {
            List<AlternativeSolutions> possol = job[i].getOperations()[j].getPossol();
          //  System.out.println(possol.size());
           
            geneSolution[j] = new GeneSolution(possol.get(r.nextInt(9999)%possol.size()).MachineID,possol.get(r.nextInt(9999)%possol.size()).time);
           
           }
     }
    }




