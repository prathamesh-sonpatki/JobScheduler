


/*
 * Chromosome Class :: Represents chromosome
 */

/**
 *
 * @author chaitanya
 */
public class Chromosome {
    int ChromosomeLength;
    int GeneCount;
    Gene genes[];

    public Chromosome() {
        ChromosomeLength = 0;
        GeneCount = 0;
        genes = null;
    }

    
    public void setChromosomeLength(int ChromosomeLength) {
        this.ChromosomeLength = ChromosomeLength;
    }

    public void setGeneCount(int GeneCount) {
        this.GeneCount = GeneCount;
    }

    public int getChromosomeLength() {
        return ChromosomeLength;
    }

    public int getGeneCount() {
        return GeneCount;
    }

    public void printChromosome()
    {
        System.out.println("Chromosome Length = "+this.getChromosomeLength());
        System.out.println("Number Of Genes = "+this.getGeneCount());
        for(int i=0;i<this.getGeneCount();i++)
        {
            System.out.println("Gene["+i+"]:");
            genes[i].printGenes();
        }
     }

    public void setGenes(Job [] job) {
       genes = new Gene[this.getGeneCount()];

       for(int i=0;i<this.getGeneCount();i++)
       {
            genes[i] = new Gene();
            
            genes[i].setGeneLength(job[i].getTotalOperations());
            
            genes[i].setGeneSolution(job,i);
       }
      
    }





}
