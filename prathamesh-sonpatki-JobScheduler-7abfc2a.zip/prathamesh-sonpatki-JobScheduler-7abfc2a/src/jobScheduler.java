
import java.io.FileNotFoundException;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author prathamesh
 */


    public class jobScheduler{

    static final int populationSize=1000;
    int TotalJobs;
    public static int getPopulationSize() {
        return populationSize;
    }
        

    public  int getTotalJobs() {
        return TotalJobs;
    }
  //  private static final int NUMBER_OF_EVOLUTIONS = 5000;
     
    
        
       public static void main(String[] args) throws FileNotFoundException {
       
        //Create Object of InputController Class and take input from user
InputController inputControllerObject = new InputController();
            inputControllerObject.GetInput();
            Job job[] = inputControllerObject.getJob();
            
        //Generate population
            PopulationController populationController = new PopulationController();
            populationController.GetPopulationDetails(job);
          // populationController.population.getChromosomes().printChromosome();

       }

}
